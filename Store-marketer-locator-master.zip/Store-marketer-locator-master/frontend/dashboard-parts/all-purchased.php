<h3>All Purchased</h3>

<div class="table-container mt-3">
	<p class="message-inquiry"></p>
	<table id="enquiryTableall" class="display">
		<thead>
		    <tr>
				
 <th width="20%">Postcode</th>
            	<th width="20%">Gender Wanted</th>
				<th width="20%">Service Type</th>
				<th width="20%">Insurance</th>
		        <th width="20%">Speciality Required</th>
				<th width="20%">Type of Lead</th>
		       
				  
		    </tr>
		</thead>
		<tbody>
		</tbody>
	</table>
</div>