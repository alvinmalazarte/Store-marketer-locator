<h3>My Leads</h3>
<div class="row">
 
 <small class="text-danger font-weight-bold font-italic">Once your lead has been purchased by a Physio it will apeear on this page.</small>
  </div>
	 
<div class="table-container mt-3">
	<p class="message-inquiry"></p>
	<table id="leadEnquiryTable" class="display">
		<thead>
		    <tr>
		           <th width="20%">Postcode</th>
            	<th width="20%">Gender Wanted</th>
				<th width="20%">Service Type</th>
				<th width="20%">Client Type</th>
		        <th width="20%">Speciality Required</th>
				
				  <th width="20%"></th>
		    </tr>
		</thead>
		<tbody>
		</tbody>
	</table>
</div>