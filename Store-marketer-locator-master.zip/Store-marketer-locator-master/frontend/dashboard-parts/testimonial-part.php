<h3 class="mb-3">Testimonial List</h3>
<table id="testimonialList" class="display">
  <thead>
    <tr>
      <th width="5%">ID</th>
      <th width="25%">Name</th>
      <th width="25%">Company</th>
      <th width="25%">Job Title</th>
      <th width="25%">Action</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>

<!-- Modal -->
<!--div class="modal fade" id="testimonialInfo" tabindex="-1" role="dialog" aria-labelledby="testimonialInfo" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="testimonialInfos">Testimonial Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="testimonial-name"><p></p></div>
        <div class="testimonial-job-title"><p></p></div>
        <div class="testimonial-company"><p></p></div>
        <div class="testimonial-content"><p></p></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div-->
